<section id="sertifikat" class="sertifikat">
    <div class="container">
        <div class="row content">
            <div class="col-lg-6 text-end align-middle">

                <h3>
                    INDEPENDENT AUDITORS' REPORT BY RIBKA ARETHA & PARTNER
                </h3>
                <p>
                    Number : 00319/2.1349/AU.1/11/1708-1/1/IX/2022
                </p>
            </div>
            <div class="col-lg-6">
                <div class="figure">
                    <a href="assets/img/idenpedent.png" data-caption='' class='item' title=''>
                        <img src="assets/img/idenpedent.png" class="rounded mx-auto d-block" width="30%">
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>