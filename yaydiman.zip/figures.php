<section id="figures" class="figures">
    <div class="container">

        <div class="section-title">
            <h2>Figure</h2>
            <p>
                Statment Of Financial & Social Giving Report
            </p>
        </div>
        <ul class="figures-list">
            <div class='figure'>
                <a href="assets/img/figures/3.jpeg" data-caption='' class='item' title=''>
                    <img src="assets/img/figures/3.jpeg" alt="second image">
                </a>
                <a href="assets/img/figures/4.jpeg" data-caption='' class='item' title=''>
                    <img src="assets/img/figures/4.jpeg" alt="second image">
                </a>
            </div>
        </ul>
    </div>
</section><!-- End F.A.Q Section -->