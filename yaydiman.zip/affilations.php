<section id="Affilations" class="Affilations">
    <div class="container">
        <div class="section-title">
            <h2>Affiliations</h2>
        </div>
        <div class="text-center">
            <section class="customer-logos slider">
                <div class="slide"><img src="./assets/img/Affililations/armadabarat.png"></div>
                <div class="slide"><img src="./assets/img/Affililations/BWTP.png"></div>
                <div class="slide"><img src="./assets/img/Affililations/gema.png"></div>
                <div class="slide"><img src="./assets/img/Affililations/jala.png"></div>
                <div class="slide"><img src="./assets/img/Affililations/jaya.png"></div>
                <div class="slide"><img src="./assets/img/Affililations/kopassus.png"></div>
                <div class="slide"><img src="./assets/img/Affililations/kostrad.png"></div>
                <div class="slide"><img src="./assets/img/Affililations/Logo-PKM.png"></div>
                <div class="slide"><img src="./assets/img/Affililations/mabes.jpg"></div>
                <div class="slide"><img src="./assets/img/Affililations/oppor.png"></div>
                <div class="slide"><img src="./assets/img/Affililations/siliwangi.png"></div>
                <div class="slide"><img src="./assets/img/Affililations/transaparancy.png"></div>
            </section>
        </div>

    </div>
</section>