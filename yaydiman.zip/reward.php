<section id="reward" class="reward">
    <div class="container">
        <div class="section-title">
            <h2>Reward And Appreciation</h2>
            <p>
                Our citations for giving the best
            </p>
        </div>
        <div class="text-center">
            <section class="customer-logos slider">
                <div class="slide"><img src="./assets/img/Reward/piagam/2012.JPG"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/2013b.jpg"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/2015.png"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/2015a.png"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/2016.jpg"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/2017.png"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/IMG_1537.png"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/IMG_1538.png"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/IMG_1540.png"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/IMG_1557.png"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/IMG_1559.png"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/IMG_1561.png"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/IMG_1563.jpg"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/IMG_1564.jpg"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/IMG_1565.jpg"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/IMG_1566.jpg"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/IMG_1567.jpg"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/IMG_1569.jpg"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/IMG_1570.jpg"></div>
                <div class="slide"><img src="./assets/img/Reward/piagam/IMG_1579.png"></div>
            </section>
        </div>
    </div>
</section>