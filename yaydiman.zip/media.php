<section id="faq" class="faq">
    <div class="container">

        <div class="section-title">
            <h2>Media</h2>
        </div>

        <ul class="faq-list">

            <article class='gallery'>
                <a href="assets/img/frank/1.jpeg" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/1.jpeg" alt="first image">
                </a>
                <a href="assets/img/frank/2.jpeg" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/2.jpeg" alt="second image">
                </a>
                <a href="assets/img/frank/3.jpeg" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/3.jpeg" alt="second image">
                </a>
                <a href="assets/img/frank/4.jpeg" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/4.jpeg" alt="second image">
                </a>
                <a href="assets/img/frank/5.jpeg" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/5.jpeg" alt="second image">
                </a>
                <a href="assets/img/frank/6.jpeg" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/6.jpeg" alt="second image">
                </a>
                <a href="assets/img/frank/7.jpeg" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/7.jpeg" alt="second image">
                </a>
                <a href="assets/img/frank/10.JPG" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/10.JPG" alt="second image">
                </a>
                <a href="assets/img/frank/8.JPG" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/8.JPG" alt="second image">
                </a>
                <a href="assets/img/frank/9.jpg" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/9.jpg" alt="second image">
                </a>
                <a href="assets/img/frank/13.jpg" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/13.jpg" alt="second image">
                </a>
                <a href="assets/img/frank/11.JPG" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/11.JPG" alt="second image">
                </a>
                <a href="assets/img/frank/12.JPG" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/12.JPG" alt="second image">
                </a>
                <a href="assets/img/frank/15.jpg" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/15.jpg" alt="second image">
                </a>
                <a href="assets/img/frank/14.jpg" data-caption='' class='item' title=''>
                    <img src="assets/img/frank/14.jpg" alt="second image">
                </a>
            </article>

        </ul>

    </div>
</section><!-- End F.A.Q Section -->